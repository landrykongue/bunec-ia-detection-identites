# Design system — Interface BUNEC (proposition à valider)

Outil interne d'aide à la vérification des actes de naissance. Utilisateurs :
agents de l'état civil (fonctionnaires), pas des profils techniques. L'interface
doit inspirer **confiance institutionnelle** et se lire comme un **logiciel
administratif officiel**, pas comme un SaaS à la mode ni un template « généré ».

## Principe directeur
Sobriété, lisibilité, traçabilité. L'agent décide ; l'outil assiste et **explique
toujours pourquoi** un dossier est signalé. Bilingue français / anglais (le
Cameroun et le BUNEC sont bilingues).

## Palette (identité nationale, avec parcimonie)
Les couleurs du drapeau servent d'accents fonctionnels, pas de décoration :
- **Vert institutionnel** `#0B6B3A` — couleur primaire (barre, en-têtes, actions principales).
- **Gris neutres** `#F4F5F3` (fond), `#E3E6E1` (bordures), `#1F2421` (texte).
- **Rouge** `#C0392B` — réservé STRICTEMENT au risque élevé / alertes.
- **Ambre** `#E0A800` — risque modéré.
- **Vert clair** `#2E7D32` — risque faible / succès.
- **Or discret** `#C99700` — filet d'accent sous l'en-tête (rappel du jaune national).

Correspondance risque ⇄ couleur = intuitive et cohérente avec l'agrégateur.

## Typographie
- Sans-serif sobre et lisible (pile système : Segoe UI / Roboto / Arial), pas de
  police « tendance ». Titres en poids semi-bold, tableaux en taille confortable.
- Libellés bilingues courts : « Cas suspects / Suspect cases ».

## Mise en page
- **Barre latérale gauche** : Importer · Tableau de bord · Cas suspects · Rapports · Journal · Aide.
- **En-tête** : bloc identité (Armoiries / logo BUNEC), titre de l'outil, nom de
  l'agent connecté, déconnexion. Filet or fin sous l'en-tête.
- **Contenu** : cartes rectangulaires sobres (coins peu arrondis, ombre discrète),
  tableaux de données denses mais aérés.

## Composants clés
- **Badges de risque** : pastille colorée + libellé (Élevé / Modéré / Faible).
- **Fiche de cas** : les deux actes côte à côte pour un doublon ; pour chaque cas,
  la liste des **caractéristiques ayant motivé l'alerte** (ex. « Jaro-Winkler nom
  mère : 0,97 »), le niveau, le type de fraude, et les actions (Confirmer /
  Faux positif / Transmettre à la DCV).
- **Tableau de bord** : 4 indicateurs (actes analysés, doublons potentiels,
  identités fictives potentielles, part à vérifier) + 2 graphiques sobres
  (répartition par niveau de risque, distribution des scores).
- **Bandeau de confidentialité** rappelant la loi n°2010/012 et la journalisation.

## À proscrire (pour ne pas « faire IA / template »)
- Pas de dégradé violet/indigo, pas de glassmorphism, pas de tout-arrondi flottant
  sur fond pastel.
- Pas d'emojis dans l'UI, pas de « ✨ Powered by AI », pas d'illustrations 3D génériques.
- Pas de tricolore criard : le vert/rouge/jaune restent des accents fonctionnels.

## Ton rédactionnel (copie)
Administratif, direct, rassurant : « Fichier importé avec succès »,
« 1 902 dossiers à vérifier en priorité », « Aucune donnée n'est conservée en
clair au-delà de la session ». Jamais de jargon « IA ».

## Contrainte technique
Doit tourner sur matériel modeste et navigateurs anciens (cf. mémoire) : HTML/CSS
sobre, Bootstrap 5 + Chart.js, aucune dépendance lourde, pages imprimables.
