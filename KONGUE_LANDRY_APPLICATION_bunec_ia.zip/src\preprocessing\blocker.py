# -*- coding: utf-8 -*-
"""Blocking multi-cles pour rendre la comparaison praticable a grande echelle.

Deux actes ne sont compares que s'ils partagent au moins une cle de bloc.
Cinq cles complementaires (cf. Tableau 2.3 du memoire) garantissent un rappel
de blocking eleve tout en reduisant drastiquement l'espace des comparaisons.
"""
from __future__ import annotations

import itertools
from collections import defaultdict

import jellyfish
import pandas as pd


class MultiKeyBlocker:
    def __init__(self, max_bloc: int = 200):
        # garde-fou : on ignore les blocs geants (peu informatifs, couteux)
        self.max_bloc = max_bloc

    @staticmethod
    def _safe(s) -> str:
        return s if isinstance(s, str) else ""

    def _cles(self, row) -> list[str]:
        nom = self._safe(row.get("nom_norm"))
        pre = self._safe(row.get("prenom_norm"))
        mere = self._safe(row.get("nom_mere_norm"))
        annee = row.get("annee")
        annee = int(annee) if pd.notna(annee) else 0
        commune = self._safe(row.get("lieu_norm"))
        cles = []
        if nom:
            cles.append("k1_" + jellyfish.soundex(nom) + str(annee // 10))
        if nom and pre:
            cles.append("k2_" + nom[:3] + pre[:3])
        if commune and annee:
            cles.append("k3_" + commune[:6] + str(annee))
        if nom and pre and row.get("date_iso"):
            cles.append("k4_" + nom[:1] + pre[:1] + str(row.get("date_iso")))
        if mere and annee:
            cles.append("k5_" + mere[:4] + str(annee))
        return cles

    def generate_pairs(self, df: pd.DataFrame) -> list[tuple[int, int]]:
        blocs: dict[str, list[int]] = defaultdict(list)
        for idx, row in df.iterrows():
            for cle in self._cles(row):
                blocs[cle].append(idx)
        paires: set[tuple[int, int]] = set()
        for indices in blocs.values():
            if len(indices) < 2 or len(indices) > self.max_bloc:
                continue
            for i, j in itertools.combinations(sorted(set(indices)), 2):
                paires.add((i, j))
        return sorted(paires)
