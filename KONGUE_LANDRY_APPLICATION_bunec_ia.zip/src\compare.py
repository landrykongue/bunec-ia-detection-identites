# -*- coding: utf-8 -*-
"""Comparaisons et etudes d'ablation.

Confronte le Random Forest a des baselines simples (regle deterministe, seuil
mono-metrique) et mesure l'apport du pretraitement (normalisation adaptee aux
noms camerounais) sur le blocking et sur la detection.

    python -m src.compare
"""
from __future__ import annotations

import time

import jellyfish
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from src.preprocessing.normalizer import NomNormalizer
from src.preprocessing.blocker import MultiKeyBlocker
from src.preprocessing.feature_engineer import FeatureEngineer
from src.models.module_a_doublon import DoublonDetector
from src.evaluation.evaluator import metriques

DATA = "data/synthetic/actes_synthetiques.csv"
SEED = 42


def identite(row):
    sid = row.get("source_id")
    return sid if isinstance(sid, str) and sid else row["id_acte"]


def transform_minimal(df: pd.DataFrame) -> pd.DataFrame:
    """Pretraitement DEGRADE : minuscules seulement, sans diacritiques ni tri.

    Sert de temoin pour mesurer l'apport de la normalisation complete.
    """
    out = df.copy()
    for col in ["nom", "prenom", "nom_mere", "nom_pere"]:
        if col in out.columns:
            out[f"{col}_norm"] = out[col].astype(str).str.lower().str.strip()
    out["date_iso"] = out["date_naissance"].map(NomNormalizer.normalize_date)
    out["annee"] = out["date_iso"].map(lambda s: int(s[:4]) if isinstance(s, str) else None)
    out["lieu_norm"] = out.get("lieu_naissance", "").astype(str).str.lower().str.strip()
    return out


def vrais_pairs(df):
    ids = df["_identite"]
    vp = set()
    for _, idxs in df.groupby("_identite").indices.items():
        if len(idxs) > 1:
            for a in range(len(idxs)):
                for b in range(a + 1, len(idxs)):
                    vp.add((min(idxs[a], idxs[b]), max(idxs[a], idxs[b])))
    return vp


def rappel_blocking(pairs, vp):
    return len(set(pairs) & vp) / max(len(vp), 1)


def main():
    df0 = pd.read_csv(DATA, encoding="utf-8-sig")

    # deux versions du pretraitement
    df_full = NomNormalizer().transform(df0)
    df_full["_identite"] = df_full.apply(identite, axis=1)
    df_min = transform_minimal(df0)
    df_min["_identite"] = df_full["_identite"].values

    vp = vrais_pairs(df_full)

    # ---- (A) Apport du pretraitement sur le BLOCKING ----
    blk = MultiKeyBlocker(max_bloc=150)
    pairs_full = blk.generate_pairs(df_full)
    pairs_min = blk.generate_pairs(df_min)
    print("=== Apport du pretraitement sur le blocking ===")
    print(f"  Normalisation complete : {len(pairs_full):,} paires, rappel {rappel_blocking(pairs_full, vp)*100:.1f} %")
    print(f"  Pretraitement minimal  : {len(pairs_min):,} paires, rappel {rappel_blocking(pairs_min, vp)*100:.1f} %")

    # ---- On fixe le meme jeu de paires (issu de la normalisation complete) ----
    fe = FeatureEngineer()
    ident = df_full["_identite"].to_dict()
    y = np.array([1 if ident[i] == ident[j] else 0 for (i, j) in pairs_full])
    X_full = fe.build_pair_matrix(df_full, pairs_full)
    X_min = fe.build_pair_matrix(df_min, pairs_full)

    idx = np.arange(len(y))
    itr, ite = train_test_split(idx, test_size=0.2, random_state=SEED, stratify=y)

    resultats = {}

    # ---- (B1) Random Forest, features normalisees (reference) ----
    det = DoublonDetector(seed=SEED).fit(X_full[itr], y[itr])
    pred = (det.predict_proba(X_full[ite]) >= 0.5).astype(int)
    resultats["Random Forest (18 features, normalisation complete)"] = metriques(y[ite], pred)

    # ---- (B2) Random Forest, features sur pretraitement minimal (ablation) ----
    det2 = DoublonDetector(seed=SEED).fit(X_min[itr], y[itr])
    pred2 = (det2.predict_proba(X_min[ite]) >= 0.5).astype(int)
    resultats["Random Forest (features sans normalisation)"] = metriques(y[ite], pred2)

    # ---- (B3) Regle deterministe : JW(nom) >= 0.90 ET meme date ----
    recs = df_full.to_dict("records")
    def regle(i, j):
        a, b = recs[i], recs[j]
        jw = jellyfish.jaro_winkler_similarity(a.get("nom_norm", ""), b.get("nom_norm", ""))
        return int(jw >= 0.90 and a.get("date_iso") and a.get("date_iso") == b.get("date_iso"))
    pred3 = np.array([regle(pairs_full[k][0], pairs_full[k][1]) for k in ite])
    resultats["Regle deterministe (JW nom >= 0,90 ET meme date)"] = metriques(y[ite], pred3)

    # ---- (B4) Seuil mono-metrique : score = 0,5 JW(nom) + 0,5 JW(prenom) ----
    def score_mono(i, j):
        a, b = recs[i], recs[j]
        return 0.5 * jellyfish.jaro_winkler_similarity(a.get("nom_norm", ""), b.get("nom_norm", "")) \
             + 0.5 * jellyfish.jaro_winkler_similarity(a.get("prenom_norm", ""), b.get("prenom_norm", ""))
    s_tr = np.array([score_mono(pairs_full[k][0], pairs_full[k][1]) for k in itr])
    s_te = np.array([score_mono(pairs_full[k][0], pairs_full[k][1]) for k in ite])
    # seuil optimise sur l'entrainement (maximise le F1)
    best_t, best_f1 = 0.5, -1
    for t in np.linspace(0.5, 0.99, 50):
        f1 = metriques(y[itr], (s_tr >= t).astype(int))["f1"]
        if f1 > best_f1:
            best_f1, best_t = f1, t
    pred4 = (s_te >= best_t).astype(int)
    resultats[f"Seuil mono-metrique (JW nom+prenom, seuil {best_t:.2f})"] = metriques(y[ite], pred4)

    # ---- Restitution ----
    print("\n=== Module A : comparaison des approches (jeu de test) ===")
    print(f"{'Approche':52s} {'Prec.':>6} {'Rappel':>7} {'F1':>6} {'TFP':>6}")
    for nom, m in resultats.items():
        print(f"{nom:52s} {m['precision']:6.3f} {m['rappel']:7.3f} {m['f1']:6.3f} {m['taux_fp']*100:5.1f}%")

    print("\nLecture : le gain du Random Forest sur la regle deterministe et sur le")
    print("seuil mono-metrique quantifie l'apport de l'apprentissage ; l'ecart entre")
    print("les deux lignes Random Forest quantifie l'apport de la normalisation.")


if __name__ == "__main__":
    main()
