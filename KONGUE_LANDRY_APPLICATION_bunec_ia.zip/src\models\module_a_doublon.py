# -*- coding: utf-8 -*-
"""Module A --- Detection des doubles identites par classification supervisee.

Foret aleatoire precedee d'une imputation, d'un reechantillonnage SMOTE et
d'une standardisation, le tout encapsule dans un pipeline (pas de fuite de
donnees entre entrainement et test).
"""
from __future__ import annotations

import numpy as np
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler


class DoublonDetector:
    def __init__(self, threshold: float = 0.50, seed: int = 42):
        self.threshold = threshold
        self.pipeline = ImbPipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("smote", SMOTE(random_state=seed, k_neighbors=5)),
            ("scaler", StandardScaler()),
            ("clf", RandomForestClassifier(
                n_estimators=200, max_depth=10, min_samples_split=5,
                max_features="sqrt", class_weight="balanced",
                random_state=seed, n_jobs=-1)),
        ])

    def fit(self, X, y):
        self.pipeline.fit(X, y)
        return self

    def predict_proba(self, X) -> np.ndarray:
        return self.pipeline.predict_proba(X)[:, 1]

    def predict(self, X) -> np.ndarray:
        return (self.predict_proba(X) >= self.threshold).astype(int)

    @property
    def feature_importances_(self):
        return self.pipeline.named_steps["clf"].feature_importances_
