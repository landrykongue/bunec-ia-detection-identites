# -*- coding: utf-8 -*-
"""Metriques d'evaluation (classification binaire)."""
from __future__ import annotations

import numpy as np
from sklearn.metrics import (confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)


def metriques(y_true, y_pred, y_score=None) -> dict:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    res = {
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "rappel": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "taux_fp": fp / (fp + tn) if (fp + tn) else 0.0,
        "vp": int(tp), "fp": int(fp), "vn": int(tn), "fn": int(fn),
    }
    if y_score is not None and len(set(y_true)) > 1:
        res["auc_roc"] = roc_auc_score(y_true, y_score)
    return res


def afficher(titre: str, m: dict):
    print(f"\n=== {titre} ===")
    print(f"  Precision : {m['precision']:.3f}")
    print(f"  Rappel    : {m['rappel']:.3f}")
    print(f"  F1-score  : {m['f1']:.3f}")
    if "auc_roc" in m:
        print(f"  AUC-ROC   : {m['auc_roc']:.3f}")
    print(f"  Taux FP   : {m['taux_fp']*100:.1f} %")
    print(f"  VP={m['vp']}  FP={m['fp']}  VN={m['vn']}  FN={m['fn']}")
