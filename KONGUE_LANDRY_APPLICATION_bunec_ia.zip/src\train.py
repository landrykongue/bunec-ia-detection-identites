# -*- coding: utf-8 -*-
"""Entraine le modele Random Forest du Module A et le sauvegarde.

Le modele est entraine une fois sur le corpus synthetique etiquete, puis
reutilise par l'application pour scorer tout fichier importe (non etiquete).

    python -m src.train
"""
from __future__ import annotations

import os

import joblib
import numpy as np
import pandas as pd

from src.preprocessing.normalizer import NomNormalizer
from src.preprocessing.blocker import MultiKeyBlocker
from src.preprocessing.feature_engineer import FeatureEngineer
from src.models.module_a_doublon import DoublonDetector

DATA = "data/synthetic/actes_synthetiques.csv"
MODEL_PATH = "models/rf_doublon.joblib"
SEED = 42


def identite(row):
    sid = row.get("source_id")
    return sid if isinstance(sid, str) and sid else row["id_acte"]


def main():
    os.makedirs("models", exist_ok=True)
    df = pd.read_csv(DATA, encoding="utf-8-sig")
    df = NomNormalizer().transform(df)
    df["_identite"] = df.apply(identite, axis=1)

    pairs = MultiKeyBlocker(max_bloc=150).generate_pairs(df)
    fe = FeatureEngineer()
    X = fe.build_pair_matrix(df, pairs)
    ident = df["_identite"].to_dict()
    y = np.array([1 if ident[i] == ident[j] else 0 for (i, j) in pairs])

    det = DoublonDetector(threshold=0.50, seed=SEED).fit(X, y)
    joblib.dump({"model": det, "features": fe.FEATURE_NAMES_A}, MODEL_PATH)
    print(f"Modele entraine sur {len(pairs):,} paires ({int(y.sum())} positifs).")
    print(f"Sauvegarde : {MODEL_PATH}")


if __name__ == "__main__":
    main()
