# -*- coding: utf-8 -*-
"""Generateur de donnees synthetiques du fichier national des actes de naissance.

Produit un corpus d'experimentation (~5 800 actes) calibre sur les
distributions demographiques camerounaises, avec verite terrain :
  - des doublons injectes selon six typologies (colonne dup_type),
  - des identites fictives injectees (colonne is_fictif),
  - des homonymes legitimes servant de negatifs difficiles (is_ambigu).

Aucune donnee reelle n'est utilisee. Reproductible via une graine fixe.

Usage :
    python -m src.generator.synthetic_gen --out data/synthetic/actes_synthetiques.csv
"""
from __future__ import annotations

import argparse
import unicodedata
from datetime import date, timedelta

import numpy as np
import pandas as pd

from src.generator.lexiques import NOMS, PRENOMS, REGIONS_DEPARTEMENTS, zipf_poids

SEED = 42

# Composition cible (cf. Tableau 2.8 du memoire)
COMPOSITION = {
    "base_legitimes": 4000,
    "doublon_orthographique": 200,
    "doublon_phonetique": 120,
    "inversion_nom_prenom": 100,
    "doublon_decalage_date": 150,
    "doublon_inter_centres": 150,
    "doublon_troncature": 80,
    "identite_fictive": 200,
    "acte_ambigu": 800,
}

DIMINUTIFS = {
    "Emmanuel": "Manu", "Francois": "Franck", "Christian": "Chris",
    "Bernard": "Ben", "Michel": "Mich", "Joseph": "Jo", "Georges": "Jojo",
    "Alexandre": "Alex", "Cedric": "Ced", "Ibrahim": "Ibro", "Amadou": "Ama",
    "Veronique": "Vero", "Solange": "Sol", "Christine": "Chris",
}


# Ponderation de Zipf sur le rang de frequence (donnees reelles)
NOMS_V, NOMS_P = NOMS, zipf_poids(len(NOMS), s=0.8)
PRENOMS_V, PRENOMS_P = PRENOMS, zipf_poids(len(PRENOMS), s=0.7)
REGIONS = list(REGIONS_DEPARTEMENTS.keys())
# Communes de reference = chefs-lieux des departements officiels
COMMUNES_PAR_REGION = {
    reg: [chef for _, chef in deps] for reg, deps in REGIONS_DEPARTEMENTS.items()
}
# Poids des regions ~ nombre de departements (proxy de population/administration)
REGIONS_P = np.array([len(REGIONS_DEPARTEMENTS[r]) for r in REGIONS], dtype=float)
REGIONS_P = REGIONS_P / REGIONS_P.sum()


class GenerateurActes:
    def __init__(self, seed: int = SEED):
        self.rng = np.random.default_rng(seed)
        self._compteur_acte = 1

    # ------------------------------------------------------------------ utils
    def _tirer_nom(self) -> str:
        return self.rng.choice(NOMS_V, p=NOMS_P)

    def _tirer_prenom(self) -> str:
        n = 1 if self.rng.random() < 0.28 else 2
        return " ".join(self.rng.choice(PRENOMS_V, p=PRENOMS_P, size=n, replace=False))

    def _tirer_lieu(self):
        region = self.rng.choice(REGIONS, p=REGIONS_P)
        commune = self.rng.choice(COMMUNES_PAR_REGION[region])
        return region, commune

    def _tirer_date_naissance(self) -> date:
        # annees 1940-2023, densite plus forte sur les recentes
        annee = int(np.clip(round(self.rng.normal(1990, 18)), 1940, 2023))
        mois = int(self.rng.integers(1, 13))
        jour = int(self.rng.integers(1, 28))
        return date(annee, mois, jour)

    def _numero_acte(self, annee: int, benford_ok: bool = True) -> str:
        if benford_ok:
            # premier chiffre suivant grossierement Benford
            premier = int(self.rng.choice(
                np.arange(1, 10),
                p=np.array([np.log10(1 + 1 / d) for d in range(1, 10)])))
            reste = int(self.rng.integers(0, 1000))
            num = premier * 1000 + reste
        else:
            # fictif : numeros a chiffres eleves / sequentiels (viole Benford)
            num = int(self.rng.integers(8000, 9999))
        n = self._compteur_acte
        self._compteur_acte += 1
        return f"{annee}/{num:04d}/{n:06d}"

    def _delai_declaration(self) -> int:
        # majorite < 90 jours, traine des declarations tardives rurales
        # plafonnee a ~3 ans (au-dela, le cas devient reellement suspect)
        if self.rng.random() < 0.78:
            return int(self.rng.integers(0, 90))
        return int(self.rng.integers(90, 1095))

    # -------------------------------------------------------------- generation
    def acte_base(self, ambigu_combo=None) -> dict:
        if ambigu_combo is not None:
            nom, prenom = ambigu_combo
        else:
            nom, prenom = self._tirer_nom(), self._tirer_prenom()
        region, commune = self._tirer_lieu()
        d_naiss = self._tirer_date_naissance()
        d_decl = d_naiss + timedelta(days=self._delai_declaration())
        sexe = self.rng.choice(["M", "F"])
        return {
            "id_acte": self._numero_acte(d_naiss.year),
            "nom": nom,
            "prenom": prenom,
            "sexe": sexe,
            "date_naissance": d_naiss.isoformat(),
            "lieu_naissance": commune,
            "region": region,
            "centre_ec": f"Centre EC {commune}",
            "nom_mere": self._tirer_nom(),
            "prenom_mere": self._tirer_prenom().split()[0],
            "nom_pere": self._tirer_nom(),
            "prenom_pere": self._tirer_prenom().split()[0],
            "age_mere": int(np.clip(round(self.rng.normal(28, 6)), 15, 48)),
            "age_pere": int(np.clip(round(self.rng.normal(34, 8)), 18, 70)),
            "date_declaration": d_decl.isoformat(),
            "source_id": None,
            "dup_type": None,
            "is_fictif": 0,
            "is_ambigu": 0,
        }

    # ----------------------------------------------------- transformations dup
    def _typo(self, s: str) -> str:
        if len(s) < 3:
            return s
        s = list(s)
        i = int(self.rng.integers(1, len(s) - 1))
        op = self.rng.choice(["swap", "drop", "dup", "sub"])
        if op == "swap":
            s[i], s[i - 1] = s[i - 1], s[i]
        elif op == "drop":
            del s[i]
        elif op == "dup":
            s.insert(i, s[i])
        else:
            voisins = "aeiouszrtnml"
            s[i] = self.rng.choice(list(voisins))
        return "".join(s)

    def _phonetique(self, s: str) -> str:
        regles = [("OU", "U"), ("PH", "F"), ("Y", "I"), ("CK", "K"),
                  ("SS", "S"), ("TCH", "CH"), ("DJ", "J"), ("OO", "O")]
        up = s.upper()
        for a, b in regles:
            if a in up:
                up = up.replace(a, b, 1)
                return up.capitalize() if s[0].isupper() else up.lower()
        return s + s[-1]  # variante par redoublement final

    def _troncature(self, prenom: str) -> str:
        premier = prenom.split()[0]
        if premier in DIMINUTIFS:
            return DIMINUTIFS[premier]
        return premier[:max(3, len(premier) // 2)]

    def doublon(self, base: dict, dup_type: str) -> dict:
        d = dict(base)
        d["id_acte"] = self._numero_acte(int(base["date_naissance"][:4]))
        d["source_id"] = base["id_acte"]
        d["dup_type"] = dup_type
        d["is_ambigu"] = 0

        if dup_type == "doublon_orthographique":
            d["nom"] = self._typo(base["nom"])
            d["prenom"] = self._typo(base["prenom"])
        elif dup_type == "doublon_phonetique":
            d["nom"] = self._phonetique(base["nom"])
        elif dup_type == "inversion_nom_prenom":
            d["nom"], d["prenom"] = base["prenom"].split()[0].upper(), base["nom"].capitalize()
        elif dup_type == "doublon_decalage_date":
            dn = date.fromisoformat(base["date_naissance"])
            if self.rng.random() < 0.5 and dn.day <= 12:
                dn2 = date(dn.year, dn.day, dn.month)  # inversion jour/mois
            else:
                dn2 = dn + timedelta(days=int(self.rng.integers(-400, 400)))
            d["date_naissance"] = dn2.isoformat()
        elif dup_type == "doublon_inter_centres":
            region, commune = self._tirer_lieu()
            d["lieu_naissance"], d["region"] = commune, region
            d["centre_ec"] = f"Centre EC {commune}"
        elif dup_type == "doublon_troncature":
            d["prenom"] = self._troncature(base["prenom"])

        # Bruit realiste sur la filiation : les erreurs de saisie touchent aussi
        # les noms des parents, et ces champs sont parfois absents lors d'une
        # re-declaration. Sans ce bruit, les doublons seraient trivialement
        # separables des homonymes legitimes.
        if self.rng.random() < 0.45:
            d["nom_mere"] = self._typo(base["nom_mere"])
        if self.rng.random() < 0.45:
            d["nom_pere"] = self._typo(base["nom_pere"])
        if self.rng.random() < 0.12:
            d["nom_pere"] = ""  # pere non renseigne a la re-declaration
        return d

    def fictif(self) -> dict:
        """Acte fabrique. Une fabrication reelle est rarement soignee : elle
        cumule generalement plusieurs incoherences. On tire 2 anomalies parmi
        un repertoire, ce qui rend le cas detectable sans etre trivial."""
        d = self.acte_base()
        annee = int(d["date_naissance"][:4])
        # numero d'acte hors du schema d'emission normal (viole Benford)
        d["id_acte"] = self._numero_acte(annee, benford_ok=False)

        repertoire = ["age_mere", "age_pere", "nom_rare", "delai", "batch", "filiation"]
        for flag in self.rng.choice(repertoire, size=3, replace=False):
            if flag == "age_mere":
                d["age_mere"] = int(self.rng.choice([12, 13, 57, 60, 63]))
            elif flag == "age_pere":
                d["age_pere"] = int(self.rng.choice([14, 15, 78, 82]))
            elif flag == "nom_rare":
                # patronyme/prenom quasi inexistants dans la base
                d["nom"] = "".join(self.rng.choice(list("QWXZ"), size=5))
                d["prenom"] = "Zyx"
            elif flag == "delai":
                d["date_declaration"] = (date.fromisoformat(d["date_naissance"])
                                         + timedelta(days=int(self.rng.integers(1800, 6000)))).isoformat()
            elif flag == "batch":
                # enregistrement en lot : date de naissance figee, meme centre
                d["date_naissance"] = f"{annee}-01-01"
                d["date_declaration"] = f"{annee}-01-02"
                d["centre_ec"] = "Centre EC Douala"
            elif flag == "filiation":
                d["nom_pere"], d["nom_mere"] = "", ""  # parents inconnus
        d["is_fictif"] = 1
        return d


def generer(seed: int = SEED) -> pd.DataFrame:
    gen = GenerateurActes(seed)
    lignes: list[dict] = []

    base = [gen.acte_base() for _ in range(COMPOSITION["base_legitimes"])]
    lignes.extend(base)

    types_doublons = [
        "doublon_orthographique", "doublon_phonetique", "inversion_nom_prenom",
        "doublon_decalage_date", "doublon_inter_centres", "doublon_troncature",
    ]
    for t in types_doublons:
        for _ in range(COMPOSITION[t]):
            src = base[int(gen.rng.integers(0, len(base)))]
            lignes.append(gen.doublon(src, t))

    for _ in range(COMPOSITION["identite_fictive"]):
        lignes.append(gen.fictif())

    # homonymes legitimes : combinaisons de noms frequents partagees par
    # plusieurs personnes distinctes (negatifs difficiles)
    combos = [(gen._tirer_nom(), gen._tirer_prenom()) for _ in range(120)]
    for _ in range(COMPOSITION["acte_ambigu"]):
        combo = combos[int(gen.rng.integers(0, len(combos)))]
        a = gen.acte_base(ambigu_combo=combo)
        a["is_ambigu"] = 1
        lignes.append(a)

    df = pd.DataFrame(lignes)
    return df.sample(frac=1, random_state=seed).reset_index(drop=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/synthetic/actes_synthetiques.csv")
    ap.add_argument("--seed", type=int, default=SEED)
    args = ap.parse_args()

    df = generer(args.seed)
    df.to_csv(args.out, index=False, encoding="utf-8-sig")

    n_doublons = df["dup_type"].notna().sum()
    n_fictifs = int(df["is_fictif"].sum())
    n_ambigus = int(df["is_ambigu"].sum())
    print(f"Actes generes        : {len(df)}")
    print(f"  - legitimes (base) : {(df['dup_type'].isna() & (df['is_fictif']==0) & (df['is_ambigu']==0)).sum()}")
    print(f"  - doublons injectes: {n_doublons}")
    print(f"  - identites fictives: {n_fictifs}")
    print(f"  - homonymes ambigus: {n_ambigus}")
    print("Repartition des doublons par typologie :")
    print(df["dup_type"].value_counts().to_string())
    print(f"Fichier ecrit : {args.out}")


if __name__ == "__main__":
    main()
