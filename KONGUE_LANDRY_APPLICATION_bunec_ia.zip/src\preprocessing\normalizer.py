# -*- coding: utf-8 -*-
"""Normalisation des actes, adaptee aux specificites des noms camerounais.

Pipeline en six etapes pour les champs nominatifs (cf. chapitre 2 du memoire) :
minuscules, suppression des diacritiques, suppression de la ponctuation,
standardisation des espaces, expansion des abreviations, tokenisation triee.
Normalisation dediee des dates (ISO 8601) et rattachement des lieux.
"""
from __future__ import annotations

import re
from datetime import date

import pandas as pd
from unidecode import unidecode


class NomNormalizer:
    ABREVIATIONS = {
        "mr": "monsieur", "m": "monsieur", "mme": "madame", "mlle": "mademoiselle",
        "st": "saint", "ste": "sainte", "dr": "docteur", "el hadj": "elhadji",
        "alh": "alhadji",
    }
    _re_ponct = re.compile(r"[^a-z0-9 ]")
    _re_espaces = re.compile(r"\s+")

    def normalize_nom(self, texte) -> str:
        if not isinstance(texte, str) or not texte.strip():
            return ""
        t = unidecode(texte).lower().strip()          # 1-2 minuscules + diacritiques
        t = self._re_ponct.sub(" ", t)                # 3 ponctuation
        t = self._re_espaces.sub(" ", t).strip()      # 4 espaces
        tokens = t.split()
        tokens = [self.ABREVIATIONS.get(tok, tok) for tok in tokens]  # 5 abreviations
        tokens = sorted(tokens)                        # 6 tokenisation triee
        return " ".join(tokens)

    @staticmethod
    def normalize_date(valeur) -> str | None:
        """Ramene une date vers ISO 8601 (AAAA-MM-JJ). Tolere les formats courants."""
        if valeur is None or (isinstance(valeur, float)):
            return None
        s = str(valeur).strip()
        if not s:
            return None
        # deja ISO
        m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$", s)
        if m:
            a, mo, j = map(int, m.groups())
        else:
            m = re.match(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$", s)  # JJ/MM/AAAA
            if not m:
                return None
            j, mo, a = map(int, m.groups())
        try:
            return date(a, mo, j).isoformat()
        except ValueError:
            # dates impossibles (jour 00, mois 13) : correction defensive
            mo = min(max(mo, 1), 12)
            j = min(max(j, 1), 28)
            return date(a, mo, j).isoformat()

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Enrichit le DataFrame de colonnes normalisees (_norm, date_iso, annee)."""
        out = df.copy()
        for col in ["nom", "prenom", "nom_mere", "nom_pere"]:
            if col in out.columns:
                out[f"{col}_norm"] = out[col].map(self.normalize_nom)
        out["date_iso"] = out["date_naissance"].map(self.normalize_date)
        out["annee"] = out["date_iso"].map(
            lambda s: int(s[:4]) if isinstance(s, str) else None)
        if "lieu_naissance" in out.columns:
            out["lieu_norm"] = out["lieu_naissance"].map(self.normalize_nom)
        return out
