# -*- coding: utf-8 -*-
"""Analyse d'un fichier d'actes pour l'interface web.

Applique le modele Random Forest pre-entraine (Module A) et l'Isolation Forest
+ LOF (Module B) a un DataFrame importe, sans etiquettes. Retourne, pour chaque
acte : score de doublon, score d'anomalie, niveau de risque, type suspecte et
les caracteristiques ayant motive l'alerte.
"""
from __future__ import annotations

import os

import joblib
import numpy as np
import pandas as pd

from src.preprocessing.normalizer import NomNormalizer
from src.preprocessing.blocker import MultiKeyBlocker
from src.preprocessing.feature_engineer import FeatureEngineer
from src.models.module_b_fictif import FictifDetector
from src.models.aggregator import ScoreAggregator

MODEL_PATH = "models/rf_doublon.joblib"
CHAMPS_REQUIS = ["id_acte", "nom", "prenom", "date_naissance"]


def valider_colonnes(df: pd.DataFrame) -> list[str]:
    return [c for c in CHAMPS_REQUIS if c not in df.columns]


def _raison_doublon(fe, a, b) -> list[str]:
    import jellyfish
    raisons = []
    n1, n2 = a.get("nom_norm", ""), b.get("nom_norm", "")
    p1, p2 = a.get("prenom_norm", ""), b.get("prenom_norm", "")
    if n1 and n2 and jellyfish.jaro_winkler_similarity(n1, n2) > 0.85:
        raisons.append("noms très proches")
    if p1 and p2 and jellyfish.jaro_winkler_similarity(p1, p2) > 0.85:
        raisons.append("prénoms très proches")
    if a.get("date_iso") and a.get("date_iso") == b.get("date_iso"):
        raisons.append("même date de naissance")
    m1, m2 = a.get("nom_mere_norm", ""), b.get("nom_mere_norm", "")
    if m1 and m2 and jellyfish.jaro_winkler_similarity(m1, m2) > 0.9:
        raisons.append("même nom de mère")
    return raisons or ["profil global similaire"]


def analyser(df_brut: pd.DataFrame) -> dict:
    """Analyse complete. Retourne un dict : resultats (DataFrame), resume, paires."""
    bundle = joblib.load(MODEL_PATH)
    detA = bundle["model"]
    fe = FeatureEngineer()

    df = NomNormalizer().transform(df_brut)
    n = len(df)
    recs = df.to_dict("records")

    # Module A : doublons
    pairs = MultiKeyBlocker(max_bloc=150).generate_pairs(df)
    score_a_acte = np.zeros(n)
    paires_suspectes = []
    if pairs:
        X = fe.build_pair_matrix(df, pairs)
        proba = detA.predict_proba(X)
        for (i, j), pr in zip(pairs, proba):
            score_a_acte[i] = max(score_a_acte[i], pr)
            score_a_acte[j] = max(score_a_acte[j], pr)
            if pr >= 0.5:
                paires_suspectes.append({
                    "i": i, "j": j, "score": float(pr),
                    "raisons": _raison_doublon(fe, recs[i], recs[j]),
                })

    # Module B : identites fictives
    XB = fe.build_act_matrix(df)
    resB = FictifDetector(contamination=0.05, seed=42).detect(XB)
    score_b = resB["score"]
    fictif_flag = resB["pred_if"]  # Isolation Forest = detecteur principal

    # Agregation
    agg = ScoreAggregator()
    niveaux = agg.niveaux(score_a_acte, score_b)

    res = df_brut.copy()
    res["score_doublon"] = np.round(score_a_acte, 3)
    res["score_anomalie"] = np.round(score_b, 3)
    res["niveau_risque"] = niveaux
    res["type_suspecte"] = np.where(
        (score_a_acte >= 0.5) & (fictif_flag == 1), "doublon + anomalie",
        np.where(score_a_acte >= 0.5, "doublon potentiel",
                 np.where(fictif_flag == 1, "identité fictive potentielle", "—")))

    resume = {
        "total": n,
        "doublons": int((score_a_acte >= 0.5).sum()),
        "fictifs": int(fictif_flag.sum()),
        "eleve": int((niveaux == "eleve").sum()),
        "modere": int((niveaux == "modere").sum()),
        "faible": int((niveaux == "faible").sum()),
        "a_verifier": int(((niveaux == "eleve") | (niveaux == "modere")).sum()),
        "nb_paires": len(paires_suspectes),
    }
    resume["part_a_verifier"] = round(resume["a_verifier"] / max(n, 1) * 100, 1)
    return {"resultats": res, "resume": resume, "paires": paires_suspectes,
            "records": recs}


def modele_disponible() -> bool:
    return os.path.exists(MODEL_PATH)
