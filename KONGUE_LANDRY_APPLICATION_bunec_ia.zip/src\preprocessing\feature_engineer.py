# -*- coding: utf-8 -*-
"""Ingenierie des caracteristiques.

- Module A : 18 caracteristiques de similarite par PAIRE d'actes.
- Module B : 12 caracteristiques statistiques par ACTE individuel.
"""
from __future__ import annotations

import math
from datetime import date

import jellyfish
import numpy as np
import pandas as pd

# Distribution de Benford (premier chiffre)
BENFORD = {d: math.log10(1 + 1 / d) for d in range(1, 10)}


def _f(s):
    return s if isinstance(s, str) else ""


def token_sort_ratio(a: str, b: str) -> float:
    ta, tb = " ".join(sorted(a.split())), " ".join(sorted(b.split()))
    if not ta and not tb:
        return 1.0
    return jellyfish.jaro_winkler_similarity(ta, tb)


def bigram_sim(a: str, b: str) -> float:
    A = {a[i:i + 2] for i in range(len(a) - 1)}
    B = {b[i:i + 2] for i in range(len(b) - 1)}
    if not A or not B:
        return 0.0
    return 2 * len(A & B) / (len(A) + len(B))


class FeatureEngineer:
    FEATURE_NAMES_A = [
        "jw_nom", "lev_nom", "bigram_nom", "jw_prenom", "tokensort_prenom",
        "soundex_prenom", "diff_jours", "meme_mois_annee", "inv_jour_mois",
        "meme_commune", "meme_region", "jw_mere", "jw_pere", "meme_centre",
        "meme_commune_centre", "score_nom_prenom", "inversion_nom_prenom",
        "score_global",
    ]

    # ------------------------------------------------------------ Module A
    def pair_features(self, a: dict, b: dict) -> np.ndarray:
        n1, n2 = _f(a.get("nom_norm")), _f(b.get("nom_norm"))
        p1, p2 = _f(a.get("prenom_norm")), _f(b.get("prenom_norm"))
        m1, m2 = _f(a.get("nom_mere_norm")), _f(b.get("nom_mere_norm"))
        pe1, pe2 = _f(a.get("nom_pere_norm")), _f(b.get("nom_pere_norm"))

        jw_nom = jellyfish.jaro_winkler_similarity(n1, n2)
        lev = jellyfish.levenshtein_distance(n1, n2)
        lev_nom = 1 - lev / max(len(n1), len(n2), 1)
        big_nom = bigram_sim(n1, n2)
        jw_pre = jellyfish.jaro_winkler_similarity(p1, p2)
        ts_pre = token_sort_ratio(p1, p2)
        sx_pre = float(bool(p1) and jellyfish.soundex(p1) == jellyfish.soundex(p2))

        d1, d2 = a.get("date_iso"), b.get("date_iso")
        if isinstance(d1, str) and isinstance(d2, str):
            dd1, dd2 = date.fromisoformat(d1), date.fromisoformat(d2)
            diff = abs((dd1 - dd2).days)
            meme_ma = float(dd1.month == dd2.month and dd1.year == dd2.year)
            inv_jm = float(dd1.day == dd2.month and dd1.month == dd2.day and dd1.year == dd2.year)
        else:
            diff, meme_ma, inv_jm = -1, 0.0, 0.0

        meme_commune = float(_f(a.get("lieu_norm")) == _f(b.get("lieu_norm")) and _f(a.get("lieu_norm")) != "")
        meme_region = float(a.get("region") == b.get("region") and a.get("region") is not None)
        jw_mere = jellyfish.jaro_winkler_similarity(m1, m2) if m1 and m2 else 0.0
        jw_pere = jellyfish.jaro_winkler_similarity(pe1, pe2) if pe1 and pe2 else 0.0
        meme_centre = float(a.get("centre_ec") == b.get("centre_ec") and a.get("centre_ec") is not None)
        meme_commune_centre = meme_commune

        score_np = 0.4 * jw_nom + 0.3 * jw_pre + 0.3 * ts_pre
        inversion = float(jellyfish.jaro_winkler_similarity(n1, p2) > 0.85
                          and jellyfish.jaro_winkler_similarity(p1, n2) > 0.85)
        score_global = 0.35 * jw_nom + 0.25 * jw_pre + 0.15 * jw_mere + 0.15 * meme_ma + 0.10 * big_nom

        return np.array([
            jw_nom, lev_nom, big_nom, jw_pre, ts_pre, sx_pre, diff, meme_ma,
            inv_jm, meme_commune, meme_region, jw_mere, jw_pere, meme_centre,
            meme_commune_centre, score_np, inversion, score_global,
        ], dtype=float)

    def build_pair_matrix(self, df: pd.DataFrame, pairs: list[tuple[int, int]]):
        recs = df.to_dict("records")
        X = np.empty((len(pairs), len(self.FEATURE_NAMES_A)), dtype=float)
        for k, (i, j) in enumerate(pairs):
            X[k] = self.pair_features(recs[i], recs[j])
        return X

    # ------------------------------------------------------------ Module B
    FEATURE_NAMES_B = [
        "freq_prenom", "freq_nom", "coherence_age_mere", "coherence_age_pere",
        "benford_num", "densite_centre_mois", "coherence_lieu_centre",
        "concentration_date", "unicite_prenom_nom", "delai_declaration",
        "incoherence_filiation", "benford_composite",
    ]

    def build_act_matrix(self, df: pd.DataFrame) -> np.ndarray:
        n = len(df)
        # stats globales
        freq_nom = df["nom_norm"].value_counts(normalize=True)
        freq_pre = df["prenom_norm"].value_counts(normalize=True)
        combo = (df["nom_norm"] + "|" + df["prenom_norm"]).value_counts()
        # densite centre x mois
        mois = df["date_iso"].map(lambda s: s[:7] if isinstance(s, str) else "NA")
        tmp = df.assign(_m=mois.values)
        dens = tmp.groupby(["centre_ec", "_m"])["id_acte"].transform("size").reset_index(drop=True)
        dens_z = (dens - dens.mean()) / (dens.std() + 1e-9)
        # concentration meme date meme centre
        conc = df.groupby(["centre_ec", "date_iso"])["id_acte"].transform("size").reset_index(drop=True)

        def benford_dev(num):
            s = "".join(ch for ch in str(num) if ch.isdigit()).lstrip("0")
            if not s:
                return 0.5
            d = int(s[0])
            return abs(1 - (0.0 if d == 0 else 1.0) * (1.0)) if d == 0 else abs(BENFORD.get(d, 0) - 1 / 9)

        X = np.zeros((n, len(self.FEATURE_NAMES_B)), dtype=float)
        recs = df.reset_index(drop=True)
        for i, row in recs.iterrows():
            nomn, pren = row.get("nom_norm", ""), row.get("prenom_norm", "")
            am, ap = row.get("age_mere", 30), row.get("age_pere", 35)
            X[i, 0] = freq_pre.get(pren, 0.0)
            X[i, 1] = freq_nom.get(nomn, 0.0)
            # ecart continu a la plage plausible (0 si normal, croissant sinon)
            X[i, 2] = float(max(0, 16 - am, am - 45))    # age mere
            X[i, 3] = float(max(0, 17 - ap, ap - 65))    # age pere
            X[i, 4] = benford_dev(row.get("id_acte"))
            X[i, 5] = float(dens_z.iloc[i])
            X[i, 6] = 0.0                                 # coherence lieu-centre (centre = commune ici)
            X[i, 7] = float(conc.iloc[i])
            X[i, 8] = float(combo.get(f"{nomn}|{pren}", 1))
            di = row.get("date_iso"); dd = row.get("date_declaration")
            if isinstance(di, str) and isinstance(dd, str):
                X[i, 9] = (date.fromisoformat(dd) - date.fromisoformat(di)).days
            mere_abs = _f(row.get("nom_mere_norm")) == ""
            pere_abs = _f(row.get("nom_pere_norm")) == ""
            X[i, 10] = float(nomn == "" or pren == "" or (mere_abs and pere_abs))
            X[i, 11] = benford_dev(row.get("id_acte"))
        return X
