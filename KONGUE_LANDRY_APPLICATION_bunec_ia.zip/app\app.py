# -*- coding: utf-8 -*-
"""Interface web BUNEC --- aide a la detection des doublons et identites fictives.

Application Flask sobre, reliee au pipeline reel. Un agent importe un fichier
d'actes, l'analyse s'execute, puis il consulte le tableau de bord, la liste
hierarchisee des cas suspects, le detail de chaque cas, et exporte les rapports.
"""
from __future__ import annotations

import io
import os
import sys

import pandas as pd
from flask import (Flask, flash, redirect, render_template, request,
                   send_file, url_for)

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from app.analysis import analyser, valider_colonnes, modele_disponible  # noqa: E402

app = Flask(__name__)
app.secret_key = "bunec-demo-key"

# Etat applicatif (demo mono-utilisateur : dernier resultat + journal d'audit)
ETAT: dict = {"analyse": None, "fichier": None}
JOURNAL: list[dict] = []


def journaliser(action: str, detail: str = ""):
    from datetime import datetime
    JOURNAL.insert(0, {"horodatage": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                       "action": action, "detail": detail})


@app.route("/")
def accueil():
    return redirect(url_for("importer"))


@app.route("/import", methods=["GET", "POST"])
def importer():
    if request.method == "POST":
        if not modele_disponible():
            flash("Modèle non entraîné. Exécutez d'abord : python -m src.train", "danger")
            return redirect(url_for("importer"))
        f = request.files.get("fichier")
        if not f or not f.filename:
            flash("Aucun fichier sélectionné.", "danger")
            return redirect(url_for("importer"))
        try:
            if f.filename.lower().endswith(".csv"):
                df = pd.read_csv(f, encoding="utf-8-sig")
            elif f.filename.lower().endswith((".xlsx", ".xls")):
                df = pd.read_excel(f)
            else:
                flash("Format non supporté. Utilisez CSV ou Excel.", "danger")
                return redirect(url_for("importer"))
        except Exception as e:
            flash(f"Lecture impossible : {e}", "danger")
            return redirect(url_for("importer"))

        manquants = valider_colonnes(df)
        if manquants:
            flash("Colonnes manquantes : " + ", ".join(manquants), "danger")
            return redirect(url_for("importer"))

        res = analyser(df)
        ETAT["analyse"] = res
        ETAT["fichier"] = f.filename
        journaliser("Importation et analyse",
                    f"{f.filename} — {res['resume']['total']} actes")
        flash(f"Fichier importé avec succès : {res['resume']['total']} actes analysés.", "success")
        return redirect(url_for("tableau_bord"))
    return render_template("import.html", actif="import")


@app.route("/demo")
def demo():
    """Charge le corpus synthetique pour demonstration."""
    df = pd.read_csv("data/synthetic/actes_synthetiques.csv", encoding="utf-8-sig")
    cols = [c for c in df.columns if c not in
            ("source_id", "dup_type", "is_fictif", "is_ambigu")]
    ETAT["analyse"] = analyser(df[cols].copy())
    ETAT["fichier"] = "actes_synthetiques.csv (démonstration)"
    journaliser("Importation et analyse",
                f"actes_synthetiques.csv — {ETAT['analyse']['resume']['total']} actes")
    flash(f"Fichier importé avec succès : {ETAT['analyse']['resume']['total']} actes analysés.", "success")
    return redirect(url_for("tableau_bord"))


@app.route("/dashboard")
def tableau_bord():
    if not ETAT["analyse"]:
        return redirect(url_for("importer"))
    r = ETAT["analyse"]["resume"]
    return render_template("dashboard.html", actif="dashboard", r=r,
                           fichier=ETAT["fichier"])


@app.route("/suspects")
def suspects():
    if not ETAT["analyse"]:
        return redirect(url_for("importer"))
    res = ETAT["analyse"]["resultats"].copy()
    res = res[res["niveau_risque"].isin(["eleve", "modere"])]
    ordre = {"eleve": 0, "modere": 1}
    res = res.assign(_o=res["niveau_risque"].map(ordre)) \
             .sort_values(["_o", "score_doublon", "score_anomalie"], ascending=[True, False, False])
    lignes = list(res.reset_index().to_dict("records"))
    return render_template("suspects.html", actif="suspects", lignes=lignes)


@app.route("/case/<int:idx>")
def cas(idx):
    if not ETAT["analyse"]:
        return redirect(url_for("importer"))
    res = ETAT["analyse"]["resultats"]
    recs = ETAT["analyse"]["records"]
    if idx not in res.index:
        flash("Cas introuvable.", "danger")
        return redirect(url_for("suspects"))
    acte = res.loc[idx].to_dict()
    # paires suspectes impliquant cet acte
    paires = []
    for p in ETAT["analyse"]["paires"]:
        if idx in (p["i"], p["j"]):
            autre = p["j"] if p["i"] == idx else p["i"]
            paires.append({"autre": res.loc[autre].to_dict(), "score": p["score"],
                           "raisons": p["raisons"]})
    return render_template("case.html", actif="suspects", idx=idx, acte=acte, paires=paires)


@app.route("/case/<int:idx>/action", methods=["POST"])
def cas_action(idx):
    decision = request.form.get("decision", "")
    libelle = {"confirme": "Confirmé comme fraude",
               "faux_positif": "Marqué faux positif",
               "dcv": "Transmis à la DCV"}.get(decision, decision)
    journaliser(libelle, f"Acte index {idx}")
    flash(f"Décision enregistrée : {libelle}.", "success")
    return redirect(url_for("suspects"))


@app.route("/export/excel")
def export_excel():
    if not ETAT["analyse"]:
        return redirect(url_for("importer"))
    buf = io.BytesIO()
    ETAT["analyse"]["resultats"].to_excel(buf, index=False, engine="openpyxl")
    buf.seek(0)
    journaliser("Export Excel")
    return send_file(buf, as_attachment=True, download_name="analyse_bunec.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/export/pdf")
def export_pdf():
    if not ETAT["analyse"]:
        return redirect(url_for("importer"))
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.pdfgen import canvas
    r = ETAT["analyse"]["resume"]
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    c.setFillColorRGB(0.043, 0.42, 0.227)
    c.rect(0, h - 2.2 * cm, w, 2.2 * cm, fill=1, stroke=0)
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 15)
    c.drawString(2 * cm, h - 1.5 * cm, "BUNEC — Rapport d'analyse des actes")
    c.setFillColorRGB(0.12, 0.14, 0.13)
    c.setFont("Helvetica", 11)
    y = h - 3.5 * cm
    lignes = [
        f"Fichier analysé : {ETAT['fichier']}",
        f"Actes analysés : {r['total']}",
        f"Doublons potentiels : {r['doublons']}",
        f"Identités fictives potentielles : {r['fictifs']}",
        f"Risque élevé : {r['eleve']}   |   Risque modéré : {r['modere']}",
        f"Dossiers à vérifier en priorité : {r['a_verifier']} ({r['part_a_verifier']} %)",
    ]
    for l in lignes:
        c.drawString(2 * cm, y, l)
        y -= 0.8 * cm
    c.setFont("Helvetica-Oblique", 8)
    c.drawString(2 * cm, 1.5 * cm, "Document confidentiel — loi n°2010/012. Aucune donnée conservée en clair au-delà de la session.")
    c.showPage()
    c.save()
    buf.seek(0)
    journaliser("Export PDF")
    return send_file(buf, as_attachment=True, download_name="rapport_bunec.pdf",
                     mimetype="application/pdf")


@app.route("/journal")
def journal():
    return render_template("journal.html", actif="journal", entrees=JOURNAL)


@app.route("/aide")
def aide():
    return render_template("aide.html", actif="aide")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
