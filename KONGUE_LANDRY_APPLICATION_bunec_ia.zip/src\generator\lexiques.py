# -*- coding: utf-8 -*-
"""Lexiques onomastiques et geographiques REELS du Cameroun.

Donnees de reference collectees pour calibrer le generateur :
  - NOMS  : 100 patronymes les plus frequents (source : Forebears.io, Cameroun),
  - PRENOMS : 100 prenoms les plus frequents (source : Forebears.io, Cameroun),
  - REGIONS_DEPARTEMENTS : les 10 regions et 58 departements officiels avec
    leur chef-lieu (source : Wikipedia, decoupage administratif du Cameroun).

Les listes sont ordonnees par frequence decroissante (rang 1 = le plus frequent).
La ponderation reelle est reconstituee par une loi de Zipf sur le rang, ce qui
reproduit la forte concentration de certains noms (BIYA, MBARGA, OUMAROU...).
Aucune donnee nominative reelle d'individu n'est utilisee.
"""
from __future__ import annotations

import numpy as np

# --- Patronymes reels, par frequence decroissante (Forebears.io) ---
NOMS = [
    "HAMADOU", "BOUBA", "OUMAROU", "MOUSSA", "MOHAMADOU", "MAHAMAT", "ADAMOU",
    "NGONO", "KENFACK", "AHMADOU", "SALI", "KENNE", "HAMAN", "HAMIDOU",
    "ABOUBAKAR", "ABDOULAYE", "YAYA", "NANA", "ALHADJI", "ISSA", "KAMGAING",
    "OUSMANOU", "AMADOU", "KENGNE", "MENGUE", "ABBA", "ALI", "NGA", "ABDOU",
    "IBRAHIMA", "MAMOUDOU", "SAIDOU", "BOUKAR", "NGAH", "ATANGANA", "IBRAHIM",
    "HAROUNA", "HASSANA", "DONGMO", "MANGA", "YOUSSOUFA", "ONANA", "YAOUBA",
    "NDONGO", "CHE", "MANA", "BELLO", "AISSATOU", "MAI", "NGONG", "MVONDO",
    "NDI", "DJIBRILLA", "ZRA", "MBALLA", "MBAH", "SOULEYMANOU", "ASTA", "ZE",
    "NGWA", "OUMAR", "BABA", "FOTSO", "ABAKAR", "MADI", "ABDOUL", "AMOUGOU",
    "SIMO", "NGO", "MBARGA", "MAL", "EYENGA", "ADOUM", "NFOR", "ESSOMBA",
    "NDJIDDA", "KAMDEM", "HADJA", "AGBOR", "NGUM", "BILOA", "FOUDA", "KUM",
    "FADIMATOU", "TALLA", "TCHINDA", "NJOYA", "NANGA", "SOUAIBOU", "TATA",
    "BIH", "NSANGOU", "DJIDDA", "MBA", "BAKARI", "MBIDA", "MVOGO", "MAGNE",
    "BELINGA", "DOUDOU",
]

# --- Prenoms reels, par frequence decroissante (Forebears.io) ---
PRENOMS = [
    "Jean", "Marie", "Joseph", "Emmanuel", "Pierre", "Aissatou", "Pauline",
    "Madeleine", "Jacqueline", "Paul", "Therese", "Fadimatou", "Jeanne",
    "Andre", "Samuel", "Martin", "Esther", "Martine", "David", "Adama",
    "Christine", "Rose", "Julienne", "Elisabeth", "Gilbert", "Daniel", "Anne",
    "Justin", "Catherine", "Suzanne", "Helene", "Aminatou", "Francois",
    "Michel", "Simon", "Bernadette", "Haoua", "Oumarou", "Eric", "Jeannette",
    "Josephine", "Adamou", "Bouba", "Dieudonne", "Marthe", "Moussa", "Alain",
    "Rachel", "Etienne", "Thomas", "Raphael", "Marceline", "Florence",
    "Ibrahim", "Agnes", "Guy", "Robert", "Charles", "Mary", "Jacques",
    "Victorine", "Victor", "Roger", "Delphine", "Albert", "John", "Monique",
    "Bernard", "Francis", "Asta", "Brigitte", "Ousmanou", "Habiba", "Abdou",
    "Richard", "Odette", "Gabriel", "Cecile", "Veronique", "Maurice",
    "Salamatou", "Amadou", "Yaya", "Serge", "Amina", "Ernest", "Mairamou",
    "Louis", "Peter", "Justine", "Pascal", "Felix", "Rosaline", "Alice",
    "Marguerite", "Abdoulaye", "Elise", "Haman", "Marcel", "Rosalie",
]

# --- Decoupage administratif reel : region -> [(departement, chef-lieu)] ---
REGIONS_DEPARTEMENTS = {
    "Adamaoua": [("Djerem", "Tibati"), ("Faro-et-Deo", "Tignere"),
                 ("Mayo-Banyo", "Banyo"), ("Mbere", "Meiganga"), ("Vina", "Ngaoundere")],
    "Centre": [("Haute-Sanaga", "Nanga-Eboko"), ("Lekie", "Monatele"),
               ("Mbam-et-Inoubou", "Bafia"), ("Mbam-et-Kim", "Ntui"),
               ("Mefou-et-Afamba", "Mfou"), ("Mefou-et-Akono", "Ngoumou"),
               ("Mfoundi", "Yaounde"), ("Nyong-et-Kelle", "Eseka"),
               ("Nyong-et-Mfoumou", "Akonolinga"), ("Nyong-et-So'o", "Mbalmayo")],
    "Est": [("Boumba-et-Ngoko", "Yokadouma"), ("Haut-Nyong", "Abong-Mbang"),
            ("Kadey", "Batouri"), ("Lom-et-Djerem", "Bertoua")],
    "Extreme-Nord": [("Diamare", "Maroua"), ("Logone-et-Chari", "Kousseri"),
                     ("Mayo-Danay", "Yagoua"), ("Mayo-Kani", "Kaele"),
                     ("Mayo-Sava", "Mora"), ("Mayo-Tsanaga", "Mokolo")],
    "Littoral": [("Moungo", "Nkongsamba"), ("Nkam", "Yabassi"),
                 ("Sanaga-Maritime", "Edea"), ("Wouri", "Douala")],
    "Nord": [("Benoue", "Garoua"), ("Faro", "Poli"),
             ("Mayo-Louti", "Guider"), ("Mayo-Rey", "Tchollire")],
    "Nord-Ouest": [("Boyo", "Fundong"), ("Bui", "Kumbo"),
                   ("Donga-Mantung", "Nkambe"), ("Menchum", "Wum"),
                   ("Mezam", "Bamenda"), ("Momo", "Mbengwi"), ("Ngo-Ketunjia", "Ndop")],
    "Ouest": [("Bamboutos", "Mbouda"), ("Haut-Nkam", "Bafang"),
              ("Hauts-Plateaux", "Baham"), ("Koung-Khi", "Bandjoun"),
              ("Menoua", "Dschang"), ("Mifi", "Bafoussam"),
              ("Nde", "Bangangte"), ("Noun", "Foumban")],
    "Sud": [("Dja-et-Lobo", "Sangmelima"), ("Mvila", "Ebolowa"),
            ("Ocean", "Kribi"), ("Vallee-du-Ntem", "Ambam")],
    "Sud-Ouest": [("Fako", "Limbe"), ("Koupe-Manengouba", "Bangem"),
                  ("Lebialem", "Menji"), ("Manyu", "Mamfe"),
                  ("Meme", "Kumba"), ("Ndian", "Mundemba")],
}


def zipf_poids(n: int, s: float = 0.8) -> np.ndarray:
    """Poids de Zipf normalises pour n elements ranges par frequence."""
    rangs = np.arange(1, n + 1, dtype=float)
    w = 1.0 / np.power(rangs, s)
    return w / w.sum()
