# -*- coding: utf-8 -*-
"""Agregateur de scores : fusionne les signaux des Modules A et B.

Un acte est suspect s'il est probablement un doublon OU une identite fictive.
Une simple somme ponderee enterrerait les fictifs (dont le score de doublon est
nul) ; on retient donc une logique par seuils sur chaque signal, plus un score
de risque continu pour le classement fin.
"""
from __future__ import annotations

import numpy as np


class ScoreAggregator:
    def __init__(self, alpha: float = 0.6, beta: float = 0.4):
        self.alpha, self.beta = alpha, beta

    def score_risque(self, score_a: np.ndarray, score_b: np.ndarray) -> np.ndarray:
        """Score continu pour le classement : on prend le signal dominant."""
        return np.maximum(self.alpha * score_a + self.beta * score_b,
                          np.maximum(score_a, score_b) * 0.9)

    @staticmethod
    def niveaux(score_a: np.ndarray, score_b: np.ndarray) -> np.ndarray:
        """Trois niveaux de risque par logique OU sur les deux signaux."""
        sb_haut = np.quantile(score_b, 0.98)
        sb_mod = np.quantile(score_b, 0.90)
        niveaux = np.full(len(score_a), "faible", dtype=object)
        mod = (score_a >= 0.50) | (score_b >= sb_mod)
        haut = (score_a >= 0.75) | (score_b >= sb_haut)
        niveaux[mod] = "modere"
        niveaux[haut] = "eleve"
        return niveaux
