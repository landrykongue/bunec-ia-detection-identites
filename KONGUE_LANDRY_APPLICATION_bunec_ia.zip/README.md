# bunec_ia — Détection des doubles identités et des identités fictives

Application d'aide à la vérification du **fichier national des actes de naissance**
du Cameroun, accompagnant le mémoire de fin de cycle d'ingénieur de
**KONGUE LANDRY** (ENSPY, filière Art et Intelligence Artificielle).

Le système repère, au sein d'un fichier d'actes, deux types d'anomalies :

- les **doubles identités** (doublons) — plusieurs actes désignant une même
  personne, par apprentissage supervisé ;
- les **identités fictives** — actes fabriqués, par détection d'anomalies non
  supervisée.

Il ne remplace pas l'agent de l'état civil : il **hiérarchise** les dossiers à
vérifier et **justifie** chaque alerte, pour concentrer le contrôle humain là où
il est utile.

---

## Sommaire

1. [Contexte](#contexte)
2. [Résultats](#résultats)
3. [Architecture](#architecture)
4. [Installation](#installation)
5. [Utilisation](#utilisation)
6. [Structure du projet](#structure-du-projet)
7. [Données de référence](#données-de-référence)
8. [Interface web](#interface-web)
9. [Limites et confidentialité](#limites-et-confidentialité)
10. [Feuille de route](#feuille-de-route)

---

## Contexte

Un fichier d'état civil fiable conditionne l'accès des citoyens à leurs droits.
Or les registres d'Afrique subsaharienne comportent une part non négligeable de
doublons et d'actes fabriqués, hérités de décennies de saisie manuelle. La
vérification exhaustive à la main est irréaliste sur des millions d'actes. Ce
projet met l'apprentissage automatique au service des agents du BUNEC.

Faute d'accès aux données réelles (confidentialité — loi n°2010/012), les
expérimentations reposent sur un **corpus synthétique** calibré sur de vraies
références démographiques et administratives camerounaises (voir
[Données de référence](#données-de-référence)).

## Résultats

Mesurés sur le corpus synthétique de 5 800 actes (graine 42, reproductible) —
détail dans `reports/resultats_pipeline.txt`.

| Composant | Résultat |
|---|---|
| **Blocking** | 120 476 paires candidates vs 16,8 M exhaustives (**réduction ×140**), rappel 99,5 % |
| **Module A — doublons** (Random Forest + SMOTE) | Précision 1,00 · Rappel 0,99 · **F1 0,99** · AUC 1,00 · TFP 0 % |
| **Module B — fictifs** (Isolation Forest) | **F1 0,75** · Rappel 0,93 · **AUC 0,99** |
| Module B — LOF seul | F1 0,13 (peu adapté à ce problème) |
| Module B — consensus IF+LOF | Précision 0,85 · Rappel 0,14 (filtre haute précision) |
| **Agrégateur** | ~**33 %** du fichier à vérifier, capturant **~99,5 %** des fraudes |

> Constat honnête : sur ce problème, l'**Isolation Forest** est le détecteur
> efficace du Module B ; le LOF (hypothèse initiale) n'apporte pas de gain, les
> fabrications n'étant pas des outliers de densité locale.

## Architecture

Pipeline modulaire en cinq étages :

```
Fichier d'actes (CSV/Excel)
        │
        ▼
  Prétraitement ── normalisation des noms camerounais (6 étapes) + dates ISO
        │
        ▼
  Blocking ─────── 5 clés de bloc (Soundex, préfixes, commune, filiation…)
        │
        ├──────────────┬───────────────┐
        ▼              ▼               │
  Module A         Module B           │
  (doublons)       (fictifs)          │
  RF + SMOTE       iForest + LOF      │
        │              │               │
        └──────┬───────┘               │
               ▼                        │
        Agrégateur ── score de risque, 3 niveaux (élevé/modéré/faible)
               │
               ▼
     Interface web / Rapports PDF-Excel
```

## Installation

Prérequis : Python 3.10+.

```bash
cd bunec_ia
pip install -r requirements.txt
```

Dépendances principales : pandas, numpy, scikit-learn, imbalanced-learn,
jellyfish, Unidecode, Flask, openpyxl, reportlab.

## Utilisation

### 1. Générer le corpus synthétique

```bash
python -m src.generator.synthetic_gen --out data/synthetic/actes_synthetiques.csv
```

Produit 5 800 actes avec vérité terrain (`source_id`, `dup_type`, `is_fictif`,
`is_ambigu`).

### 2. Évaluer le pipeline complet (recommandé pour reproduire les résultats)

```bash
python -m src.run_pipeline
```

Affiche blocking, Module A (avec performance par typologie et importances),
Module B (4 configurations) et distribution de l'agrégateur.

### 3. Entraîner et sauvegarder le modèle (nécessaire pour l'interface)

```bash
python -m src.train        # crée models/rf_doublon.joblib
```

### 4. Lancer l'interface web

```bash
python -m app.app          # http://127.0.0.1:5000
```

### 5. Comparaisons et ablations (baselines)

```bash
python -m src.compare      # -> reports/comparaisons.txt
```

Confronte le Random Forest à une règle déterministe et à un seuil mono-métrique,
et mesure l'apport du prétraitement (résultats : RF F1 0,99 vs règle 0,76 vs
seuil 0,19).

- `/import` : importer un fichier CSV/Excel réel.
- `/demo` : charger directement le corpus synthétique (démonstration).

## Structure du projet

```
bunec_ia/
├── config/
├── data/
│   ├── raw/               # références réelles collectées (+ SOURCES.md)
│   ├── processed/
│   └── synthetic/         # corpus généré
├── models/                # rf_doublon.joblib (après entraînement)
├── src/
│   ├── generator/
│   │   ├── lexiques.py           # noms/prénoms/géographie réels + Zipf
│   │   └── synthetic_gen.py      # génération du corpus + vérité terrain
│   ├── preprocessing/
│   │   ├── normalizer.py         # normalisation 6 étapes + dates
│   │   ├── blocker.py            # blocking multi-clés
│   │   └── feature_engineer.py   # 18 features (A) + 12 features (B)
│   ├── models/
│   │   ├── module_a_doublon.py   # Random Forest + SMOTE
│   │   ├── module_b_fictif.py    # Isolation Forest + LOF (batch)
│   │   └── aggregator.py         # score de risque, 3 niveaux
│   ├── evaluation/
│   │   └── evaluator.py          # métriques P/R/F1/AUC/TFP
│   ├── train.py                  # entraîne et sauvegarde le modèle A
│   └── run_pipeline.py           # pipeline complet + évaluation
├── app/
│   ├── app.py                    # routes Flask
│   ├── analysis.py               # analyse d'un fichier importé
│   ├── DESIGN.md                 # design system (spec de l'interface)
│   ├── templates/                # base, import, dashboard, suspects, case, journal, aide
│   └── static/css/bunec.css      # habillage institutionnel
├── reports/
│   ├── resultats_pipeline.txt    # résultats reproductibles
│   └── captures/                 # captures d'écran de l'interface
├── tests/
├── requirements.txt
└── README.md
```

## Données de référence

Collectées sur le web pour **calibrer** le générateur (aucune donnée nominative
réelle d'un individu). Persistées dans `data/raw/` avec `SOURCES.md` :

- **Découpage administratif** — 10 régions, 58 départements, chefs-lieux
  (Wikipédia).
- **Patronymes** — 100 noms les plus fréquents au Cameroun (Forebears.io).
- **Prénoms** — 100 prénoms les plus fréquents (Forebears.io).

La fréquence réelle est reconstituée par une **loi de Zipf** sur le rang, ce qui
reproduit la forte concentration de certains noms (HAMADOU, BOUBA, OUMAROU…).

## Interface web

Application Flask sobre, pensée comme un **logiciel administratif officiel**
(design détaillé dans `app/DESIGN.md`) : vert institutionnel, codes de risque
rouge/ambre/vert, bilingue FR/EN, sans « look IA ».

Écrans : importation (avec bandeau de confidentialité), tableau de bord
(indicateurs + graphiques), liste hiérarchisée des cas suspects, fiche de cas
(comparaison des deux actes + motifs de l'alerte), export PDF/Excel, journal
d'audit. Captures dans `reports/captures/`.

## Limites et confidentialité

- **Données synthétiques** : aussi bien calibrées soient-elles, elles ne
  reproduisent pas toute l'inventivité des fraudeurs réels. Une validation sur
  un échantillon anonymisé de données BUNEC serait un préalable à toute mise en
  production.
- **Homonymes légitimes** : la forte concentration de certains noms génère des
  cas ambigus (traités comme négatifs difficiles).
- **Pas de biométrie** : le système ne raisonne que sur du texte et des nombres.
- **Confidentialité** : données à caractère personnel au sens de la loi
  n°2010/012 ; l'interface journalise les actions et ne conserve pas les données
  en clair au-delà de la session.

## Feuille de route

1. ✅ Collecte / génération des données (générateur + vraies références)
2. ✅ Prétraitement (normalisation + blocking multi-clés)
3. ✅ Ingénierie des caractéristiques (18 + 12 features)
4. ✅ Module A — Random Forest + SMOTE
5. ✅ Module B — Isolation Forest + LOF
6. ✅ Agrégateur + évaluation
7. ✅ Interface web Flask (design institutionnel)
8. ✅ Comparaisons (règle déterministe vs seuil vs RF, ablation du prétraitement)
9. ⬜ Tests unitaires, authentification réelle, migration PostgreSQL pour la production

## Licence et usage

Projet académique. Les données de référence proviennent de sources publiques
(citées dans `data/raw/SOURCES.md`). Aucune donnée personnelle réelle n'est
incluse.
