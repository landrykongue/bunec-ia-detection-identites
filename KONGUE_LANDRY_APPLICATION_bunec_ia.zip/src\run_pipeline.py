# -*- coding: utf-8 -*-
"""Pipeline complet : prétraitement -> blocking -> features -> modeles -> evaluation.

Usage :
    python -m src.run_pipeline
"""
from __future__ import annotations

import time

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from src.preprocessing.normalizer import NomNormalizer
from src.preprocessing.blocker import MultiKeyBlocker
from src.preprocessing.feature_engineer import FeatureEngineer
from src.models.module_a_doublon import DoublonDetector
from src.models.module_b_fictif import FictifDetector
from src.models.aggregator import ScoreAggregator
from src.evaluation.evaluator import metriques, afficher

DATA = "data/synthetic/actes_synthetiques.csv"
SEED = 42


def identite(row):
    sid = row.get("source_id")
    return sid if isinstance(sid, str) and sid else row["id_acte"]


def main():
    t0 = time.time()
    df = pd.read_csv(DATA, encoding="utf-8-sig")
    print(f"Actes charges : {len(df)}")

    # 1. Pretraitement
    df = NomNormalizer().transform(df)
    df["_identite"] = df.apply(identite, axis=1)

    # 2. Blocking
    blocker = MultiKeyBlocker(max_bloc=150)
    pairs = blocker.generate_pairs(df)
    n_total = len(df) * (len(df) - 1) // 2
    print(f"Paires candidates : {len(pairs):,} (vs {n_total:,} paires exhaustives, "
          f"reduction x{n_total/max(len(pairs),1):.0f})")

    # rappel de blocking : proportion des vrais doublons captures
    ident = df["_identite"].to_dict()
    id_acte = df["id_acte"].to_dict()
    vrais_pairs = set()
    groupes = df.groupby("_identite").indices
    for _, idxs in groupes.items():
        if len(idxs) > 1:
            for a in range(len(idxs)):
                for b in range(a + 1, len(idxs)):
                    vrais_pairs.add((min(idxs[a], idxs[b]), max(idxs[a], idxs[b])))
    captures = vrais_pairs & set(pairs)
    recall_block = len(captures) / max(len(vrais_pairs), 1)
    print(f"Vrais doublons (paires) : {len(vrais_pairs)} | captures par blocking : "
          f"{len(captures)} -> rappel blocking = {recall_block*100:.1f} %")

    # 3. Features + labels (Module A)
    fe = FeatureEngineer()
    print("Calcul des 18 features par paire...")
    X = fe.build_pair_matrix(df, pairs)
    y = np.array([1 if ident[i] == ident[j] else 0 for (i, j) in pairs])
    # typologie du doublon pour chaque paire positive (pour l'analyse par type)
    dtype = df["dup_type"].to_dict()
    pair_type = np.array([
        (dtype[i] if isinstance(dtype[i], str) else dtype[j]) if ident[i] == ident[j] else "neg"
        for (i, j) in pairs], dtype=object)
    print(f"Matrice A : {X.shape} | positifs = {int(y.sum())} | negatifs = {int((y==0).sum())}")

    # 4. Module A : entrainement / test
    idx = np.arange(len(y))
    Xtr, Xte, ytr, yte, itr, ite = train_test_split(
        X, y, idx, test_size=0.2, random_state=SEED, stratify=y)
    det = DoublonDetector(threshold=0.50, seed=SEED).fit(Xtr, ytr)
    proba = det.predict_proba(Xte)
    ypred = (proba >= 0.50).astype(int)
    mA = metriques(yte, ypred, proba)
    afficher("MODULE A -- Detection des doublons (jeu de test)", mA)

    # performance par typologie de doublon (rappel sur les positifs du test)
    print("  Performance par typologie (rappel sur le test) :")
    tt = pair_type[ite]
    for t in ["doublon_orthographique", "doublon_phonetique", "inversion_nom_prenom",
              "doublon_decalage_date", "doublon_inter_centres", "doublon_troncature"]:
        masque = (tt == t)
        n = int(masque.sum())
        if n:
            rec = float(ypred[masque].mean())
            print(f"    {t:26s} n={n:3d}  rappel={rec:.3f}")

    # importance des 18 features
    imp = det.feature_importances_
    order = np.argsort(imp)[::-1]
    print("  Importance des features :")
    for r, k in enumerate(order, 1):
        print(f"    {r:2d}. {fe.FEATURE_NAMES_A[k]:22s} {imp[k]:.3f}")

    # 5. Module B : detection d'identites fictives
    print("\nCalcul des 12 features par acte (Module B)...")
    XB = fe.build_act_matrix(df)
    yB = df["is_fictif"].to_numpy()
    res_b = FictifDetector(contamination=0.05, seed=SEED).detect(XB)
    score_b = res_b["score"]
    afficher("MODULE B -- Isolation Forest seul", metriques(yB, res_b["pred_if"], score_b))
    afficher("MODULE B -- LOF seul", metriques(yB, res_b["pred_lof"], score_b))
    afficher("MODULE B -- Consensus IF + LOF (vote binaire)", metriques(yB, res_b["pred_consensus"], score_b))
    afficher("MODULE B -- Score combine IF+LOF (seuil top-5%)", metriques(yB, res_b["pred_score"], score_b))

    # 6. Agregateur : score de risque par acte
    # score_a(acte) = proba de doublon maximale parmi les paires qui le concernent
    proba_all = det.predict_proba(X)
    score_a_acte = np.zeros(len(df))
    for (i, j), pr in zip(pairs, proba_all):
        score_a_acte[i] = max(score_a_acte[i], pr)
        score_a_acte[j] = max(score_a_acte[j], pr)
    agg = ScoreAggregator(alpha=0.6, beta=0.4)
    niveaux = pd.Series(agg.niveaux(score_a_acte, score_b))
    vraie_fraude = ((df["dup_type"].notna()) | (df["is_fictif"] == 1)).to_numpy()
    print("\n=== AGREGATEUR -- distribution par niveau de risque ===")
    for niv in ["eleve", "modere", "faible"]:
        masque = (niveaux == niv).to_numpy()
        n = int(masque.sum())
        vf = int(vraie_fraude[masque].sum())
        prec = vf / n if n else 0
        print(f"  {niv:7s} : {n:5d} actes ({n/len(df)*100:4.1f} %)  dont vraies fraudes : "
              f"{vf:4d}  (precision {prec*100:4.1f} %)")
    a_verifier = int(((niveaux == "eleve") | (niveaux == "modere")).sum())
    print(f"  -> a verifier manuellement : {a_verifier} actes ({a_verifier/len(df)*100:.1f} % du fichier)")

    print(f"\nTemps total : {time.time()-t0:.1f} s")


if __name__ == "__main__":
    main()
