# -*- coding: utf-8 -*-
"""Module B --- Detection des identites fictives par isolation d'anomalies.

Mode batch : l'outil recoit un fichier complet d'actes et signale, en son sein,
les enregistrements anormaux. Isolation Forest et Local Outlier Factor operent
en parallele ; un acte est signale comme fictif selon deux strategies :
  - consensus : les DEUX detecteurs s'accordent (precision elevee, peu de FP) ;
  - score combine : moyenne des scores d'anomalie, seuillee (meilleur rappel).
"""
from __future__ import annotations

import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import StandardScaler


def _minmax(v: np.ndarray) -> np.ndarray:
    return (v - v.min()) / (np.ptp(v) + 1e-9)


class FictifDetector:
    def __init__(self, contamination: float = 0.05, seed: int = 42):
        self.contamination = contamination
        self.scaler = StandardScaler()
        self.iforest = IsolationForest(
            n_estimators=200, contamination=contamination,
            max_features=1.0, random_state=seed)
        # LOF en mode detection d'outliers sur le lot (novelty=False)
        self.lof = LocalOutlierFactor(
            n_neighbors=20, contamination=contamination)

    def detect(self, X) -> dict:
        """Analyse un lot d'actes. Retourne predictions et scores."""
        Xs = self.scaler.fit_transform(X)
        # Isolation Forest
        self.iforest.fit(Xs)
        pred_if = (self.iforest.predict(Xs) == -1).astype(int)
        score_if = -self.iforest.score_samples(Xs)
        # Local Outlier Factor (batch)
        pred_lof = (self.lof.fit_predict(Xs) == -1).astype(int)
        score_lof = -self.lof.negative_outlier_factor_
        # combinaisons
        score = (_minmax(score_if) + _minmax(score_lof)) / 2
        pred_consensus = ((pred_if == 1) & (pred_lof == 1)).astype(int)
        seuil = np.quantile(score, 1 - self.contamination)
        pred_score = (score >= seuil).astype(int)
        return {
            "pred_if": pred_if, "pred_lof": pred_lof,
            "pred_consensus": pred_consensus, "pred_score": pred_score,
            "score": score,
        }
