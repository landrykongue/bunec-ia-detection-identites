# Sources des données de référence (collectées le 2026-07-16)

Ces jeux de référence servent uniquement à *calibrer* le générateur de données
synthétiques. Aucune donnée nominative réelle d'un individu n'est utilisée.

- **decoupage_administratif_cameroun.csv** — 10 régions, 58 départements et
  chefs-lieux. Source : Wikipédia, « Départements du Cameroun »
  (https://fr.wikipedia.org/wiki/Départements_du_Cameroun).
- **patronymes_frequents_cameroun.csv** — 100 patronymes les plus fréquents au
  Cameroun, par rang de fréquence. Source : Forebears.io
  (https://forebears.io/cameroon/surnames).
- **prenoms_frequents_cameroun.csv** — 100 prénoms les plus fréquents au
  Cameroun, par rang de fréquence. Source : Forebears.io
  (https://forebears.io/cameroon/forenames).

La pondération de fréquence est reconstituée par une loi de Zipf sur le rang.
